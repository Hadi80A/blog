package org.hammasir.blog.dto;

public record StateRequestDto(String state) {
}
