package org.hammasir.blog.dto;

public record NearbyRequestDto(double  x,double  y,double distance) {
}
