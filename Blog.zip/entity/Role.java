package org.hammasir.blog.entity;

public enum Role {
    USER,
    ADMIN
}
